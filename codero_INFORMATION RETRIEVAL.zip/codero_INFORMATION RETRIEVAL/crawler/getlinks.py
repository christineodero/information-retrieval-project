import urllib.request, urllib.parse, urllib.error
from bs4 import BeautifulSoup
from christineAssign6 import fetch
import logging
import time

logging.basicConfig(format="%(asctime)s - %(message)s", level=logging.INFO)


# get all links inside <a> anchor tag
def links_home(link: str):
    html = urllib.request.urlopen(link).read()
    return (BeautifulSoup(html, "html.parser"))('a')


# get all text(link) inside href
#  <a href = "https://memphis.edu">memphis</a>
def get_href(tags: list):
    return [tag.get('href') for tag in tags]


# since we do have first set of links we will go ahead to extract extra links inside the extracted links
def morelinks(link: str):
    return get_href(links_home(link))


# removing ID links
def cleaning_links(links: list):
    return [
        link
        for link in links
        if not ((link.startswith("#")) or (link.startswith('//')))
    ]


if __name__ == "__main__":
    # getting all the links from the main page
    total = get_href(links_home("https://www.memphis.edu/"))
    # clean to remove ll ID links
    total = set(cleaning_links(total))
    other_links = []
    # loop in each link generated from main page(total) to prodeuce additional links then save then inside other_links variable
    for link in total:
        time.sleep(5)
        try:
            other_links.append(', '.join(cleaning_links(get_href(links_home(link)))))
            print(other_links)
        except:
            print(f'their is problem with {link}')
    print(other_links)
total_links = total.union(set(other_links))
# saving the generated links inside txt file
with open('../links.txt', 'w') as f:
    for line in total_links:
        f.write(line)
        f.write('\n')


# getting data from website and saving it into .txt file
def webpage_to_txt(links: set):
    count = 0
    for url in links:
        logging.info(f"Getting data from {count} out of {len(links)}")
        try:
            fetch(url)
        except:
            logging.info(f"Error Getting data from {url}")
            continue
        count += 1


webpage_to_txt(total_links)
