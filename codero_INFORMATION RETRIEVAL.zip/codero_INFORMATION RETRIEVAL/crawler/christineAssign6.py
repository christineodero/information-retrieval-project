import io
import re
import logging
from requests import get
from bs4 import BeautifulSoup as bs
from PyPDF2 import PdfFileReader
from urllib.request import urlopen

logging.basicConfig(format="%(asctime)s - %(message)s", level=logging.INFO)
path = "/output"
output = r"output/"

complete_urls = []
myfiles = 0


def countWords(content):
    wordCount = len(content.split(" "))
    return wordCount > 50


# saving data into text file
def save(site, content, name):
    global output, myfiles
    content = re.sub(" +", " ", content)
    if countWords(content):
        with open(output + name + ".txt", "w") as file:
            file.write(f"{site}{content}")
            file.close()
        myfiles += 1
        return myfiles


# checking links that have social links
def find_social_link(link):
    socialLinks = ["google", "youtube"]
    return any(i in link for i in socialLinks)


# converting pdf into txt
def savePdf(hL):
    data = urlopen(hL).read()
    temp = io.BytesIO(data)
    pdfFile = PdfFileReader(temp)
    combine = pdfFile.getPage(0).extractText().replace("\n", "")
    combine = re.sub(" +", " ", combine)
    if len(combine.split(" ")) > 50:
        save(hL, combine, "output{0}".format(str(myfiles)))

        import tokenize

        stream = tokenize.open(myfiles)  # @UndefinedVariable
        try:
            contents = stream.read()
        finally:
            stream.close()


# seperating files
def seperatingFiles(link):
    global complete_urls
    hL = link.attrs["href"]

    if hL.startswith("/") and len(hL.count(".php")) == 1:
        hL = site + hL

    if hL not in complete_urls and find_social_link(hL) == False:

        if hL.endswith(".pdf"):
            savePdf(hL)

        elif hL.endswith(".txt"):
            r = get(hL, allow_redirects=False, timeout=20)
            s = bs(r.text, "html.parser")
            combine = s.get_text()
            if len(combine.split(" ")) > 50:
                save(combine, "output{0}".format(str(myfiles)))
        else:
            fetch(hL)
        complete_urls.append(hL)


# getting data from each link
def fetch(site):
    global myfiles, complete_urls
    # if myfiles < 1:
    res = get(site, timeout=5)
    res_html = bs(res.text, features="html.parser")
    res_html_text = res_html.get_text()
    if len(res_html_text) > 0:
        save(site, res_html_text, "output{0}".format(str(myfiles)))

if __name__ == "__main__":
    # start_indexing()
    logging.info("Getting data from memphis.edu")
    fetch(site)
    print("documents Generated")
    # indexing = Index()
